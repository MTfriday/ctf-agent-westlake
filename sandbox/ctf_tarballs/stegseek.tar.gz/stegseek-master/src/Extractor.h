/*
 * steghide 0.5.1 - a steganography program
 * Copyright (C) 1999-2003 Stefan Hetzl <shetzl@chello.at>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef SH_EXTRACTOR_H
#define SH_EXTRACTOR_H

#include <string>

class Extractor {
  public:
    Extractor(std::string stgfn, std::string pp)
        : StegoFileName(stgfn), Passphrase(pp), passphraseSet(true){};

    Extractor(std::string stgfn, UWORD32 seed)
        : StegoFileName(stgfn), seed(seed), passphraseSet(false){};

    EmbData *extract(void);

  private:
    std::string StegoFileName;
    std::string Passphrase;
    UWORD32 seed;
    bool passphraseSet;
};

#endif // ndef SH_EXTRACTOR_H
